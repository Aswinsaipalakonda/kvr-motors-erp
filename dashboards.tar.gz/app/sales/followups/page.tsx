import SalesDashboard from "../sales-dashboard";

export default function Page() {
  return <SalesDashboard initialTab="followups" />;
}
